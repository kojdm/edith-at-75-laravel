<div class="modal-content">
    <h5>About this website</h5>
    <hr>
    <p>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Mattis enim ut tellus elementum sagittis vitae. Lacinia at quis risus sed vulputate. Semper viverra nam libero justo laoreet. Tellus integer feugiat scelerisque varius morbi enim nunc faucibus a. Vitae auctor eu augue ut lectus. Potenti nullam ac tortor vitae. Et odio pellentesque diam volutpat commodo sed. Facilisi etiam dignissim diam quis enim lobortis scelerisque fermentum. Integer quis auctor elit sed vulputate mi.
        <br><br>
        Eget mauris pharetra et ultrices neque ornare. Nisi vitae suscipit tellus mauris. Dictum varius duis at consectetur lorem donec. Nulla facilisi cras fermentum odio eu feugiat pretium. Faucibus vitae aliquet nec ullamcorper sit amet risus nullam eget. Lacus vel facilisis volutpat est velit egestas dui id. Id venenatis a condimentum vitae sapien pellentesque habitant morbi tristique. Magna sit amet purus gravida quis blandit turpis cursus. Mauris vitae ultricies leo integer malesuada nunc vel risus commodo. Sit amet volutpat consequat mauris nunc congue. Varius vel pharetra vel turpis nunc eget lorem dolor sed. Rhoncus est pellentesque elit ullamcorper dignissim cras.
    </p>
</div>


<div class="modal-footer">
    <a href="#!" class="modal-close waves-effect btn-flat">Close</a>
</div>