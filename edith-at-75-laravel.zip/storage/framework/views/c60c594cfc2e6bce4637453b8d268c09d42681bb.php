<?php $__env->startSection('content'); ?>
    <h1>Upload</h1>

    <form action="/file-upload"
      class="dropzone"
      id="my-awesome-dropzone"></form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>