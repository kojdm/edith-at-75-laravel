<div id="gallery">
    <?php if(count($images) > 0): ?>
        <div id="macy-container">
            <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="image-container">
                    <div class="item">
                        <img src="uploads/gallery/<?php echo e($image->filename); ?>" alt='<?php echo e($image->caption); ?><br><small>FROM <?php echo e(strtoupper($image->uploader_name)); ?></small>' class="myImg" srcset="">
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php else: ?>
        <div class="image-container center">
            <div class="item">
                <img src="placeholder.jpg" alt="Hi! I'm just a placeholder. Upload your own images of Edith using the button on the top-right of this site! <br><small>FROM KOJI</small>" class="myImg" srcset="" style="height: 450px;">
            </div>
        </div>
    <?php endif; ?>
</div>


<div id="myModal" class="img-modal">
    <!-- The Close Button -->
    <span class="close">&times;</span>
    <!-- Modal Content (The Image) -->
    <img class="img-modal-content" id="img-display">
    <!-- Modal Caption (Image Text) -->
    <div id="caption"></div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    var imageCount = <?php echo e(count($images)); ?>

    if (imageCount < 5) {
        var numColumns = imageCount;
    }
    else {
        var numColumns = 5;
    }
    if (($(window).width() <= 600) && imageCount > 2) {
        var numColumns = 3;
    }
    if (imageCount > 0) {
        var macy = Macy({
            container: "#macy-container",
            trueOrder: false,
            waitForImages: true,
            margin: 0,
            columns: numColumns,
        });
    }

    // Get the modal
    var modal = document.getElementById("myModal");

    // Get the image and insert it inside the modal - use its "alt" text as a caption
    var img = $(".myImg");
    var modalImg = $("#img-display");
    var captionText = document.getElementById("caption");
    $(".myImg").click(function() {
        modal.style.display = "block";
        var newSrc = this.src;
        modalImg.attr("src", newSrc);
        captionText.innerHTML = this.alt;
    });

    var span = document.getElementsByClassName("close")[0];
    // When the user clicks on <span> (x), close the modal
    span.onclick = function() {
    modal.style.display = "none";
    };

    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    };

</script>
<?php $__env->stopPush(); ?>