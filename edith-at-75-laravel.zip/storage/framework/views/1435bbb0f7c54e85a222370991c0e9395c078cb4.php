<?php $__env->startSection('content'); ?>
    <h1 class="yellow-text">Edith @ 75</h1>
    <div class="fixed-action-btn">
        <a href="upload" class="btn-floating btn-large waves-effect waves-light yellow"><i class="material-icons">add</i></a>        
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>