<!DOCTYPE html>

<!-- What are YOU doing here??? -->

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="A website for Edith's 75th birthday. Upload images and leave messages for her to see.">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta id="token" name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="icon" href="favicon.ico" type="image/x-icon">
    <title><?php echo e(config('app.name', 'Edith @ 75')); ?></title>

    
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">

    
    <link rel="stylesheet" href="dropzonejs/dropzone.css">

    
    <link href="https://fonts.googleapis.com/css?family=Lato|Playfair+Display:400,400i" rel="stylesheet">
    <link rel="stylesheet" href="css/custom.css">
</head>
<body>
    <header>
        <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </header>

    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <footer>
        <div id="footer">
            <p><small>created by Koji Del Mundo for his lola</small></p>
        </div>
    </footer>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="dropzonejs/dropzone.js"></script>
    <script src="js/macy.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>