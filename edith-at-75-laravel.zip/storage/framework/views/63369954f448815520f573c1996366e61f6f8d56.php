<?php $__env->startSection('content'); ?>
    

    <div id="uploadModal" class="modal modal-fixed-footer">
        <?php echo $__env->make('upload', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>

    <div id="aboutModal" class="modal modal-fixed-footer">
        <?php echo $__env->make('about', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>

    <div class="container">
        <?php echo $__env->make('gallery', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function(){
        $('#uploadModal').modal({
            dismissible: false,
        });
        $('#aboutModal').modal();
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>