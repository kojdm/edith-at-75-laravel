<?php $__env->startSection('content'); ?>

<div class="carousel-wrapper">
<?php if(count($images) > 0): ?>
    <div class="carousel">
        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a class="carousel-item" href="#">
                <img src="uploads/gallery/<?php echo e($image->filename); ?>" alt='<?php echo e($image->caption); ?><br><small>FROM <?php echo e(strtoupper($image->uploader_name)); ?></small>' class="myImg" srcset="">
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php else: ?>
    <div class="image-container center">
        <div class="item">
            <img src="placeholder.jpg" alt="Hi! I'm just a placeholder. Upload your own images of Edith using the button on the top-right of this site! <br><small>FROM KOJI</small>" class="myImg" srcset="" style="height: 450px;">
        </div>
    </div>
<?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
  $(document).ready(function() {
    $('.carousel').carousel({
        numVisible: 3,
        dist: -70,
        shift: 20,
    });
  });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>